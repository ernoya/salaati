package com.prayernow.prayer_now

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
